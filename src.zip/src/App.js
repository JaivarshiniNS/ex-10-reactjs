import React from 'react';
import Webpages from '../webpages';function App() {
  return (
    <div>
      <Webpages />
    </div>
  );
}
export default App;